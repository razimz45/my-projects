
# Restructured Project for Deployment

## Client (Frontend)
- Located in the `client` directory.
- Use this folder for Netlify deployment.
- Build command: `npm run build`.
- Publish directory: `dist`.

## Server (Backend)
- Located in the `server` directory.
- Use this folder for Render deployment.
- Ensure dependencies are installed (`npm install`).
- Entry point: `server/index.js`.

## Notes
- `netlify.toml` has been added to the client for Netlify configuration.
